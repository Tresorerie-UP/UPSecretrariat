 - Tobias, le 24.02.2019
Je me suis planté de mois dans la date de cette facture (09 au lieu de 01) du coup le service financier de l'EPFL a noté la date du 04.02.2019 dans leur système.
